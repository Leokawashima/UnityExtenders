2023 5/10 最終更新

＜概要＞
BeginnerMeshLearning
階層
	Formatフォルダ
		MeshLearningFormatClass.cs
	BeginnerMeshLearning.cs

＜内容＞
・MeshLearningFormatClass.cs
	これは解説用のスクリプトのフォーマットを定義するためのスクリプト。
	今は超初心者向けの一つしかないがいずれ数を増やしてちょっとした知識につながるようなものを増やしたい。
	頑張れ未来の俺。
・BeginnerMeshLearning.cs
	これは超初心者向けの解説と実際にメッシュをスクリプトで生成するまでを行うスクリプト。
	500行以上ふざけた雰囲気で説明が続くので鼻くそでもほじりながら眺めてみると楽しい。
	簡単に図解をコメント内に入れたが学校の環境でだいぶ文字化けしていたのでその内画像を別途用意して、
	理解の手助けになるようにしたい。